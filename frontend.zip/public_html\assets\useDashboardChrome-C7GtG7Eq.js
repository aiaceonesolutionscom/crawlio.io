import{g as t}from"./index-CukCYOQW.js";function o(){return t()}export{o as u};
